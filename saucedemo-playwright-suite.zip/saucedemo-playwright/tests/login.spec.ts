import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';

// P1 login test cases from SauceDemo Test Suite (LOGIN-01, 04-09, 15)

test.describe('Login - P1', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.goto();
  });

  test('LOGIN-01: successful login with standard_user', async ({ page }) => {
    await loginPage.login('standard_user', 'secret_sauce');
    await expect(page).toHaveURL(/inventory\.html/);
    await expect(page.locator('.inventory_list')).toBeVisible();
  });

  test('LOGIN-04: login with locked_out_user is blocked', async ({ page }) => {
    await loginPage.login('locked_out_user', 'secret_sauce');
    await loginPage.expectErrorContains('Sorry, this user has been locked out');
    await expect(page).toHaveURL('https://www.saucedemo.com/');
  });

  test('LOGIN-05: login with wrong password fails', async () => {
    await loginPage.login('standard_user', 'wrong_password');
    await loginPage.expectErrorContains('Username and password do not match');
  });

  test('LOGIN-06: login with unregistered username fails with generic error', async () => {
    await loginPage.login('nonexistent_user_123', 'secret_sauce');
    await loginPage.expectErrorContains('Username and password do not match');
  });

  test('LOGIN-07: login with empty username shows required error', async () => {
    await loginPage.passwordInput.fill('secret_sauce');
    await loginPage.loginButton.click();
    await loginPage.expectErrorContains('Username is required');
  });

  test('LOGIN-08: login with empty password shows required error', async () => {
    await loginPage.usernameInput.fill('standard_user');
    await loginPage.loginButton.click();
    await loginPage.expectErrorContains('Password is required');
  });

  test('LOGIN-09: login with both fields empty shows username error first', async () => {
    await loginPage.loginButton.click();
    await loginPage.expectErrorContains('Username is required');
  });

  test('LOGIN-15: direct URL access to inventory without login redirects to login', async ({ page }) => {
    await page.goto('/inventory.html');
    await expect(page).toHaveURL('https://www.saucedemo.com/');
    await loginPage.expectErrorContains("you are logged in");
  });
});
