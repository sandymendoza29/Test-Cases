import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { InventoryPage } from '../pages/InventoryPage';
import { CartPage } from '../pages/CartPage';

// P1 cart test cases from SauceDemo Test Suite (CART-01, 02, 04, 05)

const ITEM_1 = 'Sauce Labs Backpack';
const ITEM_2 = 'Sauce Labs Bike Light';
const ITEM_3 = 'Sauce Labs Bolt T-Shirt';

test.describe('Cart - P1', () => {
  let inventoryPage: InventoryPage;

  test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', 'secret_sauce');
    inventoryPage = new InventoryPage(page);
  });

  test('CART-01: adding a single item updates badge and button state', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);

    await expect(inventoryPage.cartBadge).toHaveText('1');
    await expect(inventoryPage.itemCard(ITEM_1).getByRole('button', { name: 'Remove' })).toBeVisible();
  });

  test('CART-02: adding multiple items reflects correct badge count and cart contents', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.addToCartByName(ITEM_2);
    await inventoryPage.addToCartByName(ITEM_3);

    await expect(inventoryPage.cartBadge).toHaveText('3');

    await inventoryPage.goToCart();
    const cartPage = new CartPage(page);
    await expect(cartPage.cartItems).toHaveCount(3);
    await expect(cartPage.cartItemByName(ITEM_1)).toBeVisible();
    await expect(cartPage.cartItemByName(ITEM_2)).toBeVisible();
    await expect(cartPage.cartItemByName(ITEM_3)).toBeVisible();
  });

  test('CART-04: removing an item from the inventory page reverts button and decrements badge', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.addToCartByName(ITEM_2);
    await expect(inventoryPage.cartBadge).toHaveText('2');

    await inventoryPage.removeFromCartByName(ITEM_1);

    await expect(inventoryPage.cartBadge).toHaveText('1');
    await expect(inventoryPage.itemCard(ITEM_1).getByRole('button', { name: 'Add to cart' })).toBeVisible();
  });

  test('CART-05: removing an item from the cart page removes it and updates badge', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.addToCartByName(ITEM_2);
    await inventoryPage.goToCart();

    const cartPage = new CartPage(page);
    await cartPage.removeItemByName(ITEM_1);

    await expect(cartPage.cartItems).toHaveCount(1);
    await expect(inventoryPage.cartBadge).toHaveText('1');
  });
});
