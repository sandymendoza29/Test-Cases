import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { InventoryPage } from '../pages/InventoryPage';

// P1 product listing test case from SauceDemo Test Suite (PROD-01)

test.describe('Product Listing - P1', () => {
  test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', 'secret_sauce');
  });

  test('PROD-01: all 6 products display with name, image, price, and Add to cart button', async ({ page }) => {
    const inventoryPage = new InventoryPage(page);

    await expect(inventoryPage.inventoryItems).toHaveCount(6);

    const count = await inventoryPage.inventoryItems.count();
    for (let i = 0; i < count; i++) {
      const item = inventoryPage.inventoryItems.nth(i);
      await expect(item.locator('.inventory_item_name')).toBeVisible();
      await expect(item.locator('.inventory_item_img img')).toBeVisible();
      await expect(item.locator('.inventory_item_price')).toBeVisible();
      await expect(item.getByRole('button', { name: 'Add to cart' })).toBeVisible();
    }
  });
});
