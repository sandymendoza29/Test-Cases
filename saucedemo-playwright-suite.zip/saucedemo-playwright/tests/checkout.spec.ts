import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { InventoryPage } from '../pages/InventoryPage';
import { CheckoutPage } from '../pages/CheckoutPage';

// P1 checkout test cases from SauceDemo Test Suite (CHK-01, 02, 03, 04, 08, 09, 10, 11)

const ITEM_1 = 'Sauce Labs Backpack';
const ITEM_2 = 'Sauce Labs Bike Light';
const ITEM_3 = 'Sauce Labs Bolt T-Shirt';

test.describe('Checkout - P1', () => {
  let inventoryPage: InventoryPage;
  let checkoutPage: CheckoutPage;

  test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', 'secret_sauce');
    inventoryPage = new InventoryPage(page);
    checkoutPage = new CheckoutPage(page);
  });

  test('CHK-01: complete full checkout happy path', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.goToCart();
    await page.locator('#checkout').click();

    await checkoutPage.fillInfo('Ada', 'Lovelace', '12345');
    await checkoutPage.continueToOverview();
    await checkoutPage.finish();

    await expect(checkoutPage.completeHeader).toHaveText('Thank you for your order!');
  });

  test('CHK-02: checkout with a single item shows correct summary', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.goToCart();
    await page.locator('#checkout').click();

    await checkoutPage.fillInfo('Grace', 'Hopper', '54321');
    await checkoutPage.continueToOverview();

    await expect(checkoutPage.summaryItems).toHaveCount(1);
    await expect(page.locator('.inventory_item_name')).toHaveText(ITEM_1);
  });

  test('CHK-03: checkout with multiple items lists all items in summary', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.addToCartByName(ITEM_2);
    await inventoryPage.addToCartByName(ITEM_3);
    await inventoryPage.goToCart();
    await page.locator('#checkout').click();

    await checkoutPage.fillInfo('Katherine', 'Johnson', '11111');
    await checkoutPage.continueToOverview();

    await expect(checkoutPage.summaryItems).toHaveCount(3);
  });

  test('CHK-04: overview totals are mathematically correct (subtotal + tax = total)', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.addToCartByName(ITEM_2);
    await inventoryPage.goToCart();
    await page.locator('#checkout').click();

    await checkoutPage.fillInfo('Margaret', 'Hamilton', '90210');
    await checkoutPage.continueToOverview();

    const priceSum = await checkoutPage.getItemPricesSum();
    const subtotal = await checkoutPage.getSubtotal();
    const tax = await checkoutPage.getTax();
    const total = await checkoutPage.getTotal();

    // Sum of individual item prices should equal the displayed subtotal
    expect(subtotal).toBeCloseTo(priceSum, 2);
    // Subtotal + tax should equal the displayed total (allow for rounding)
    expect(total).toBeCloseTo(subtotal + tax, 2);
  });

  test('CHK-08: checkout with missing first name shows required error', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.goToCart();
    await page.locator('#checkout').click();

    await checkoutPage.lastNameInput.fill('Lovelace');
    await checkoutPage.zipInput.fill('12345');
    await checkoutPage.continueToOverview();

    await checkoutPage.expectErrorContains('First Name is required');
  });

  test('CHK-09: checkout with missing last name shows required error', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.goToCart();
    await page.locator('#checkout').click();

    await checkoutPage.firstNameInput.fill('Ada');
    await checkoutPage.zipInput.fill('12345');
    await checkoutPage.continueToOverview();

    await checkoutPage.expectErrorContains('Last Name is required');
  });

  test('CHK-10: checkout with missing zip/postal code shows required error', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.goToCart();
    await page.locator('#checkout').click();

    await checkoutPage.firstNameInput.fill('Ada');
    await checkoutPage.lastNameInput.fill('Lovelace');
    await checkoutPage.continueToOverview();

    await checkoutPage.expectErrorContains('Postal Code is required');
  });

  test('CHK-11: checkout with all fields empty shows first required field error', async ({ page }) => {
    await inventoryPage.addToCartByName(ITEM_1);
    await inventoryPage.goToCart();
    await page.locator('#checkout').click();

    await checkoutPage.continueToOverview();

    await checkoutPage.expectErrorContains('First Name is required');
  });
});
