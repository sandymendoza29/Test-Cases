import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { InventoryPage } from '../pages/InventoryPage';

// P1 navigation test cases from SauceDemo Test Suite (NAV-04, NAV-07)

test.describe('Navigation - P1', () => {
  let inventoryPage: InventoryPage;

  test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('standard_user', 'secret_sauce');
    inventoryPage = new InventoryPage(page);
  });

  test('NAV-04: logout returns to login page and clears session', async ({ page }) => {
    await inventoryPage.logout();

    await expect(page).toHaveURL('https://www.saucedemo.com/');
    await expect(page.locator('#login-button')).toBeVisible();
  });

  test('NAV-07: protected inventory page is not accessible after logout', async ({ page }) => {
    await inventoryPage.logout();

    await page.goto('/inventory.html');

    await expect(page).toHaveURL('https://www.saucedemo.com/');
    await expect(page.locator('[data-test="error"]')).toContainText('you are logged in');
  });
});
