# SauceDemo Playwright Suite (P1 Cases)

Automated tests for the highest-priority (P1) cases from the SauceDemo Test Suite,
built with [Playwright](https://playwright.dev/) + TypeScript using the Page Object Model.

## Coverage (22 P1 cases)

| Spec file | Test IDs |
|---|---|
| `tests/login.spec.ts` | LOGIN-01, 04, 05, 06, 07, 08, 09, 15 |
| `tests/products.spec.ts` | PROD-01 |
| `tests/cart.spec.ts` | CART-01, 02, 04, 05 |
| `tests/checkout.spec.ts` | CHK-01, 02, 03, 04, 08, 09, 10, 11 |
| `tests/navigation.spec.ts` | NAV-04, 07 |

## Setup

```bash
npm install
npx playwright install --with-deps chromium
```

## Run

```bash
npm test              # headless run, all specs
npm run test:headed   # see the browser
npm run test:ui       # Playwright's interactive UI mode
npm run report        # open the last HTML report
```

Run a single file or test:

```bash
npx playwright test tests/checkout.spec.ts
npx playwright test -g "CHK-04"
```

## Project structure

```
saucedemo-playwright/
├── playwright.config.ts   # baseURL, reporters, browser projects
├── pages/                 # Page Object Model classes
│   ├── LoginPage.ts
│   ├── InventoryPage.ts
│   ├── CartPage.ts
│   └── CheckoutPage.ts
└── tests/                 # Spec files, one per suite area
    ├── login.spec.ts
    ├── products.spec.ts
    ├── cart.spec.ts
    ├── checkout.spec.ts
    └── navigation.spec.ts
```

## Notes

- Tests run against the live `https://www.saucedemo.com` — no mocking, so a real
  network connection is required.
- `CHK-04` validates totals mathematically (subtotal = sum of item prices, total =
  subtotal + tax) instead of hardcoding prices/tax rates, so it stays valid if
  SauceDemo changes product prices.
- All P1 tests use `standard_user`. Cases involving `locked_out_user` are covered
  in `login.spec.ts` (LOGIN-04).
