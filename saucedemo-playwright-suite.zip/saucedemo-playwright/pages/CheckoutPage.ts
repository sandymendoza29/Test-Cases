import { Page, Locator, expect } from '@playwright/test';

export class CheckoutPage {
  readonly page: Page;

  // Step One - information
  readonly firstNameInput: Locator;
  readonly lastNameInput: Locator;
  readonly zipInput: Locator;
  readonly continueButton: Locator;
  readonly errorMessage: Locator;

  // Step Two - overview
  readonly summaryItems: Locator;
  readonly itemPrices: Locator;
  readonly subtotalLabel: Locator;
  readonly taxLabel: Locator;
  readonly totalLabel: Locator;
  readonly finishButton: Locator;

  // Step Three - complete
  readonly completeHeader: Locator;

  constructor(page: Page) {
    this.page = page;

    this.firstNameInput = page.locator('#first-name');
    this.lastNameInput = page.locator('#last-name');
    this.zipInput = page.locator('#postal-code');
    this.continueButton = page.locator('#continue');
    this.errorMessage = page.locator('[data-test="error"]');

    this.summaryItems = page.locator('.cart_item');
    this.itemPrices = page.locator('.inventory_item_price');
    this.subtotalLabel = page.locator('.summary_subtotal_label');
    this.taxLabel = page.locator('.summary_tax_label');
    this.totalLabel = page.locator('.summary_total_label');
    this.finishButton = page.locator('#finish');

    this.completeHeader = page.locator('.complete-header');
  }

  async fillInfo(firstName: string, lastName: string, zip: string) {
    await this.firstNameInput.fill(firstName);
    await this.lastNameInput.fill(lastName);
    await this.zipInput.fill(zip);
  }

  async continueToOverview() {
    await this.continueButton.click();
  }

  async finish() {
    await this.finishButton.click();
  }

  async expectErrorContains(text: string) {
    await expect(this.errorMessage).toBeVisible();
    await expect(this.errorMessage).toContainText(text);
  }

  /** Parses "$29.99" style text into a number */
  private static parseMoney(text: string): number {
    return parseFloat(text.replace('$', '').trim());
  }

  async getItemPricesSum(): Promise<number> {
    const texts = await this.itemPrices.allTextContents();
    return texts.reduce((sum, t) => sum + CheckoutPage.parseMoney(t), 0);
  }

  async getSubtotal(): Promise<number> {
    const text = await this.subtotalLabel.textContent();
    return CheckoutPage.parseMoney(text!.split(':')[1]);
  }

  async getTax(): Promise<number> {
    const text = await this.taxLabel.textContent();
    return CheckoutPage.parseMoney(text!.split(':')[1]);
  }

  async getTotal(): Promise<number> {
    const text = await this.totalLabel.textContent();
    return CheckoutPage.parseMoney(text!.split(':')[1]);
  }
}
