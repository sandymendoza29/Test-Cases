import { Page, Locator } from '@playwright/test';

export class CartPage {
  readonly page: Page;
  readonly cartItems: Locator;
  readonly checkoutButton: Locator;
  readonly continueShoppingButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.cartItems = page.locator('.cart_item');
    this.checkoutButton = page.locator('#checkout');
    this.continueShoppingButton = page.locator('#continue-shopping');
  }

  cartItemByName(name: string) {
    return this.page.locator('.cart_item', { has: this.page.locator('.inventory_item_name', { hasText: name }) });
  }

  async removeItemByName(name: string) {
    await this.cartItemByName(name).getByRole('button', { name: 'Remove' }).click();
  }

  async goToCheckout() {
    await this.checkoutButton.click();
  }
}
