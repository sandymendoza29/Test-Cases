import { Page, Locator } from '@playwright/test';

export class InventoryPage {
  readonly page: Page;
  readonly inventoryItems: Locator;
  readonly cartBadge: Locator;
  readonly cartIcon: Locator;
  readonly menuButton: Locator;
  readonly logoutLink: Locator;

  constructor(page: Page) {
    this.page = page;
    this.inventoryItems = page.locator('.inventory_item');
    this.cartBadge = page.locator('.shopping_cart_badge');
    this.cartIcon = page.locator('.shopping_cart_link');
    this.menuButton = page.locator('#react-burger-menu-btn');
    this.logoutLink = page.locator('#logout_sidebar_link');
  }

  itemCard(name: string) {
    return this.page.locator('.inventory_item', { has: this.page.locator('.inventory_item_name', { hasText: name }) });
  }

  async addToCartByName(name: string) {
    await this.itemCard(name).getByRole('button', { name: 'Add to cart' }).click();
  }

  async removeFromCartByName(name: string) {
    await this.itemCard(name).getByRole('button', { name: 'Remove' }).click();
  }

  async goToCart() {
    await this.cartIcon.click();
  }

  async logout() {
    await this.menuButton.click();
    await this.logoutLink.click();
  }
}
